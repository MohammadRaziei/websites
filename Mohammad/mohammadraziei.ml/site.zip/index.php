<?php
// PHP permanent URL redirection test
// header("Location: fa", true, 301);
header("Location: fa");
exit();
?>

