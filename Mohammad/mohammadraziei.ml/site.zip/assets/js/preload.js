// $(window).load(function() {
//   $("body").removeClass("preload");
// });


// $(window).load(function() {
// // $(document).ready(function(){
//      $("#tt-preloader").css({
//     display: 'none'
//      });

// });

document.addEventListener("load", function () {
    document.getElementById("tt-preloader").style.display = 'none';
});





// // hide content
// $("#hide").hide();

// hide loading
// $("#tt-preloader").hide();

// fade in loading animation
// setTimeout($('#loading').fadeIn(), 200);

// jQuery(window).load(function() {
//   $("#tt-preloader").fadeIn();

//   $("#loading").fadeOut(function() {
//     $(this).remove();
//     clearInterval(loadingAnim);
//   });

//   setTimeout(function() {
//     $("#error").fadeIn();
//   }, 60000);
// });


